export SSH_ASKPASS="/usr/bin/ksshaskpass"
